Gothenburg urban land cover: 5-class ground truth for TEE
==========================================================

7,483 polygons in 5 classes covering 80.9 % of a 5 km x 5 km viewport in central
Gothenburg, Sweden: 11.9250 to 12.0092 E, 57.6847 to 57.7297 N (TEE viewport grid 661 x 353 pixels).

Use:      class field "name", year 2024.
Fields:   name      class name (BUILDINGS, STREET, FOREST, RIVER, FOOTBALL FIELD)
          class_id  the same classes as 1-5
          color     the label colour used in TEE (Labels -> Import shows the polygons as labels)

Labelled pixels per class (pixels of that viewport grid):
  BUILDINGS        54,392 px  (28.8 %)
  STREET           66,903 px  (35.5 %)
  FOREST           49,832 px  (26.4 %)
  RIVER            16,561 px  ( 8.8 %)
  FOOTBALL FIELD    1,015 px  ( 0.5 %)

Unlabelled pixels are not a class: they were not labelled, they are not "background".

How it was made (October 2026)
1. Drawn by hand in TEE's manual labelling mode: polygons of each class over TEE's satellite
   basemap, checked by eye.
2. Part of FOREST started as a cluster of TEE's k-means auto-label that was promoted to a label
   (1,364 polygons), then checked by eye and corrected by hand like the rest.
   13,162 of the 49,832 FOREST pixels are labelled only by these polygons.
3. OpenStreetMap was used only to check the labels: an OSM-based draft was compared with them,
   but none of its polygons are in this dataset.
4. The labels were rasterised on the viewport grid (pixel-centre rule) and written as polygons
   along the pixel edges, cut so that no polygon has a hole. Polygons do not overlap.

Made by
  Christopher Kröss   https://github.com/PrismaDiamond
  Alice Piacentini    https://github.com/AlicePiacentini
  Isabel Reguera      https://github.com/IsabelReguera
  Elias Svensson      https://github.com/swesmo
in the "TESSERA Clusterings" project at Chalmers University of Technology (course DAT300/DIT616,
autumn 2026), where it served as the ground truth for scoring TEE's auto-label clustering.
