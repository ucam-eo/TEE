Gothenburg urban land cover: 5-class ground truth for TEE
==========================================================

7,483 polygons in 5 classes covering 80.9 % of a 5 km x 5 km viewport in central
Gothenburg, Sweden: 11.9250 to 12.0092 E, 57.6847 to 57.7297 N (TEE viewport grid 661 x 353 pixels).

Use:      class field "name", year 2024.
Fields:   name      class name (BUILDINGS, STREET, FOREST, RIVER, FOOTBALL FIELD)
          class_id  the same classes as 1-5
          color     the label colour used in TEE (Labels -> Import shows the polygons as labels)

Labelled pixels per class (pixels of that viewport grid):
  BUILDINGS        54,392 px  (28.8 %)
  STREET           66,903 px  (35.5 %)
  FOREST           49,832 px  (26.4 %)
  RIVER            16,561 px  ( 8.8 %)
  FOOTBALL FIELD    1,015 px  ( 0.5 %)

Unlabelled pixels are not a class: they were not labelled, they are not "background".

How it was made (October 2026)
1. Draft from OpenStreetMap (Overpass extract of 14 Oct 2026): buildings, water, wood / forest,
   soccer pitches and roads buffered to their width. A pixel gets a class when the OSM feature
   covers at least half of it.
2. Corrections drawn by hand in TEE's manual labelling mode over the satellite basemap: missing or
   wrong areas were drawn with the right class, or erased. Hand-drawn labels win over the draft.
   Part of FOREST was first proposed by TEE's k-means auto-label and then checked and corrected by
   hand, so FOREST is not fully independent of the embeddings.
3. The combined class map was written as polygons along the pixel edges of the viewport grid,
   cut so that no polygon has a hole. Polygons do not overlap.

Made by the "TESSERA Clusterings" student project at Chalmers University of Technology
(course DAT300/DIT616, autumn 2026), where it served as the ground truth for scoring TEE's
auto-label clustering.

Licence
Contains information from OpenStreetMap, (c) OpenStreetMap contributors, available under the
Open Database License (ODbL) 1.0: https://www.openstreetmap.org/copyright
As a database derived from OpenStreetMap, this dataset is made available under the ODbL 1.0
(https://opendatacommons.org/licenses/odbl/1-0/).
